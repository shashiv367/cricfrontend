import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../services/api_service.dart';
import '../services/supabase_client.dart';
import 'dart:developer' as developer;

class LiveDetailScreen extends StatefulWidget {
  final String? matchIdFromArgs;
  const LiveDetailScreen({super.key, this.matchIdFromArgs});

  @override
  State<LiveDetailScreen> createState() => _LiveDetailScreenState();
}

class _LiveDetailScreenState extends State<LiveDetailScreen> {
  int _expandedInnings = 1; // 0 for first, 1 for second, -1 for none
  Map<String, dynamic>? _match;
  bool _loading = true;
  String? _matchId;
  int _initialTabIndex = 1; // Default to LIVE tab

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_matchId == null) {
      final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      _matchId = widget.matchIdFromArgs ?? args?['matchId'];
      final initialTab = args?['initialTabIndex'];
      if (initialTab != null) {
        _initialTabIndex = initialTab;
      }
      
      if (_matchId != null) {
        _loadMatchDetails();
      } else {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _loadMatchDetails() async {
    if (_matchId == null) return;
    setState(() => _loading = true);
    try {
      final token = await supabase.auth.currentSession?.accessToken;
      
      final response = await ApiService.getMatchScoreboard(token: token, matchId: _matchId!);
      if (mounted) {
        setState(() {
          _match = response['match'];
          _loading = false;
        });
      }
    } catch (e) {
      developer.log('Error loading match details: $e');
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: const Center(child: CircularProgressIndicator(color: AppColors.primaryElectric)),
      );
    }

    if (_match == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Match Details')),
        body: const Center(child: Text('Match not found')),
      );
    }

    return DefaultTabController(
      length: 7,
      initialIndex: _initialTabIndex,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFF3F4F6),
                Colors.white,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _BallAndBatPainter(),
                ),
              ),
              Column(
                children: [
                  _buildAppBar(context),
                  Expanded(
                    child: TabBarView(
                      children: [
                        _buildInfoTab(),
                        _buildLiveTab(),
                        _buildScorecardTab(),
                        _buildSquadsTab(),
                        _buildOversTab(),
                        _buildAnalysisTab(),
                        _buildHighlightsTab(),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getTeamName(dynamic teamData, String fallback) {
    if (teamData is Map) {
      return teamData['name']?.toString() ?? fallback;
    } else if (teamData is List && teamData.isNotEmpty) {
      final first = teamData[0];
      if (first is Map) return first['name']?.toString() ?? fallback;
    }
    return fallback;
  }

  Widget _buildAppBar(BuildContext context) {
    final teamA = _getTeamName(_match?['team_a'] ?? _match?['team_a_details'], 'Team A');
    final teamB = _getTeamName(_match?['team_b'] ?? _match?['team_b_details'], 'Team B');

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.primaryElectric, Color(0xFF7C3AED)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Row(
                      children: [
                        Text(
                          '$teamA v $teamB',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        const Icon(Icons.arrow_drop_down, color: Colors.white),
                      ],
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.refresh, color: Colors.white), onPressed: _loadMatchDetails),
                  IconButton(icon: const Icon(Icons.notifications_none, color: Colors.white), onPressed: () {}),
                  IconButton(icon: const Icon(Icons.more_vert, color: Colors.white), onPressed: () {}),
                ],
              ),
            ),
            const TabBar(
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicatorColor: Colors.white,
              indicatorWeight: 3,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              labelStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              dividerColor: Colors.transparent,
              padding: EdgeInsets.symmetric(horizontal: 10),
              tabs: [
                Tab(text: 'INFO'),
                Tab(text: 'LIVE'),
                Tab(text: 'SCORECARD'),
                Tab(text: 'SQUADS'),
                Tab(text: 'OVERS'),
                Tab(text: 'ANALYSIS'),
                Tab(text: 'HIGHLIGHTS'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // --- INFO TAB ---
  Widget _buildInfoTab() {
    return Container(
      color: Colors.transparent,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInfoSection('INFO', {
              'Series': 'Tournament Match',
              'Match Status': _match?['status']?.toUpperCase() ?? 'SCHEDULED',
              'Date': _match?['start_date'] != null ? DateTime.parse(_match!['start_date']).toLocal().toString().split(' ')[0] : 'TBA',
              'Venue': _match?['venue_details']?['name'] ?? 'TBA',
              'Overs': (_match?['overs'] ?? 20).toString(),
            }),
            _buildInfoSection('TEAMS', {
              'Team A': _match?['team_a']?['name'] ?? 'TBA',
              'Team B': _match?['team_b']?['name'] ?? 'TBA',
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoSection(String title, Map<String, String> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppColors.textSecondary)),
        ),
        ...data.entries.map((e) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(width: 100, child: Text(e.key, style: const TextStyle(color: AppColors.textSecondary))),
              Expanded(child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w500, color: AppColors.textPrimary))),
            ],
          ),
        )),
        const Divider(height: 1),
      ],
    );
  }

  // --- LIVE TAB ---
  Widget _buildLiveTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildScoreHeader(),
          _buildLivePartnership(),
          _buildMiniScorecard(),
          _buildCommentaryHighlights(),
        ],
      ),
    );
  }

  Widget _buildScoreHeader() {
    final score = _match?['score'];
    final status = _match?['status'];
    final teamAName = _match?['team_a']?['name'] ?? 'Team A';
    final teamBName = _match?['team_b']?['name'] ?? 'Team B';

    final teamAScore = score?['team_a_score'] ?? 0;
    final teamAWkts = score?['team_a_wkts'] ?? 0;
    final teamAOvers = score?['team_a_overs'] ?? 0.0;
    
    final teamBScore = score?['team_b_score'] ?? 0;
    final teamBWkts = score?['team_b_wkts'] ?? 0;
    final teamBOvers = score?['team_b_overs'] ?? 0.0;

    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(teamAName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('SCORE', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  Text('$teamAScore/$teamAWkts ($teamAOvers)', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(teamBName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('SCORE', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  Text('$teamBScore/$teamBWkts ($teamBOvers)', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            status == 'live' ? 'Match is LIVE' : status == 'completed' ? 'Match Completed' : 'Match Scheduled',
            style: const TextStyle(color: AppColors.accentSunset, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildLivePartnership() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: Colors.grey.withOpacity(0.05),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("P'SHIP 1(3)", style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.bold, fontSize: 12)),
          Text('MORE', style: TextStyle(color: AppColors.primaryElectric, fontWeight: FontWeight.bold, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildMiniScorecard() {
    final playerStats = List<Map<String, dynamic>>.from(_match?['playerStats'] ?? []);
    
    // Sort player stats by innings/batting order if available
    final teamAId = _match?['team_a']?['id'];
    final teamBId = _match?['team_b']?['id'];

    // For Live tab, show current batters and bowlers
    // This is a simplification: we take the first 2 who have runs/balls or wickets/overs
    final batters = playerStats.where((p) => (p['balls'] ?? 0) > 0).take(2).toList();
    final bowlers = playerStats.where((p) => (p['overs'] ?? 0) > 0).take(2).toList();

    return Column(
      children: [
        if (batters.isNotEmpty) ...[
          _buildMiniHeader(['Batter', 'R', 'B', '4s', '6s', 'SR']),
          ...batters.map((b) => _buildMiniRow([
            b['player_name'] ?? 'Unknown',
            (b['runs'] ?? 0).toString(),
            (b['balls'] ?? 0).toString(),
            (b['fours'] ?? 0).toString(),
            (b['sixes'] ?? 0).toString(),
            _getStrikeRate(b)
          ], isStriker: true)),
        ],
        const Divider(height: 1),
        if (bowlers.isNotEmpty) ...[
          _buildMiniHeader(['Bowler', 'O', 'M', 'R', 'W', 'ER']),
          ...bowlers.map((b) => _buildMiniRow([
            b['player_name'] ?? 'Unknown',
            (b['overs'] ?? 0).toString(),
            '0', // Maidens not in schema yet
            (b['runs_conceded'] ?? 0).toString(), // Ensure this exists in backend
            (b['wickets'] ?? 0).toString(),
            _getEconomy(b)
          ])),
        ],
        const Divider(height: 1),
      ],
    );
  }

  String _getStrikeRate(Map<String, dynamic> p) {
    if (p['strike_rate'] != null) return p['strike_rate'].toString();
    final runs = p['runs'] ?? 0;
    final balls = p['balls'] ?? 0;
    if (balls == 0) return '0.00';
    return (runs / balls * 100).toStringAsFixed(2);
  }

  String _getEconomy(Map<String, dynamic> p) {
    if (p['economy'] != null) return p['economy'].toString();
    final runs = p['runs_conceded'] ?? 0;
    final overs = p['overs'] ?? 0;
    if (overs == 0) return '0.00';
    return (runs / overs).toStringAsFixed(2);
  }

  Widget _buildMiniHeader(List<String> labels) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(flex: 3, child: Text(labels[0], style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))),
          ...labels.skip(1).map((l) => Expanded(child: Text(l, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)))),
        ],
      ),
    );
  }

  Widget _buildMiniRow(List<String> values, {bool isStriker = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Expanded(flex: 3, child: Text(values[0], style: TextStyle(fontWeight: FontWeight.bold, color: isStriker ? AppColors.primaryElectric : AppColors.textPrimary))),
          ...values.skip(1).map((v) => Expanded(child: Text(v, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w500, color: AppColors.textPrimary)))),
        ],
      ),
    );
  }

  Widget _buildCommentaryHighlights() {
    final commentary = List<Map<String, dynamic>>.from(_match?['commentary'] ?? []);
    if (commentary.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(32),
        child: Center(child: Text('No commentary available yet.', style: TextStyle(color: Colors.grey))),
      );
    }

    return Column(
      children: [
        ...commentary.map((c) => _commentaryItem(
          '${c['over_number']}.${c['ball_number']}',
          c['event_type'] ?? '',
          c['commentary_text'] ?? '',
        )),
      ],
    );
  }

  Widget _commentaryItem(String over, String event, String text) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Text(over, style: const TextStyle(fontWeight: FontWeight.bold)),
              if (event.isNotEmpty) ...[
                const SizedBox(height: 4),
                _eventBadge(event),
              ],
            ],
          ),
          const SizedBox(width: 16),
           Expanded(child: Text(text, style: const TextStyle(height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _eventBadge(String event) {
    Color bg = Colors.grey;
    if (event == 'W') bg = AppColors.accentSunset;
    if (event == '4') bg = AppColors.primaryElectric;
    if (event == '6') bg = Colors.purple;
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
      child: Center(child: Text(event, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold))),
    );
  }

  // --- SCORECARD TAB ---
  Widget _buildScorecardTab() {
    final score = _match?['score'];
    final teamA = _getTeamName(_match?['team_a'], 'Team A');
    final teamB = _getTeamName(_match?['team_b'], 'Team B');
    
    final teamAScore = '${score?['team_a_score'] ?? 0}-${score?['team_a_wkts'] ?? 0} (${score?['team_a_overs'] ?? 0})';
    final teamBScore = '${score?['team_b_score'] ?? 0}-${score?['team_b_wkts'] ?? 0} (${score?['team_b_overs'] ?? 0})';

    return SingleChildScrollView(
      child: Column(
        children: [
          _inningsSection(teamA, teamAScore, 0),
          if (_expandedInnings == 0) _buildInningsContent(0),
          _inningsSection(teamB, teamBScore, 1),
          if (_expandedInnings == 1) _buildInningsContent(1),
        ],
      ),
    );
  }

  Widget _inningsSection(String team, String score, int index) {
    bool isExpanded = _expandedInnings == index;
    return InkWell(
      onTap: () {
        setState(() {
          if (_expandedInnings == index) {
            _expandedInnings = -1; // Collapse if already open
          } else {
            _expandedInnings = index; // Expand if closed
          }
        });
      },
      child: Container(
        color: isExpanded ? AppColors.primaryElectric.withOpacity(0.9) : Colors.grey[50], // Removed green
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
             Text(team, style: TextStyle(color: isExpanded ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.bold)),
             Row(
               children: [
                 Text(score, style: TextStyle(color: isExpanded ? Colors.white : AppColors.textPrimary, fontWeight: FontWeight.bold)),
                 Icon(isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: isExpanded ? Colors.white : AppColors.textSecondary),
               ],
             ),
          ],
        ),
      ),
    );
  }

  Widget _buildInningsContent(int inningsIndex) {
    final teamAId = _match?['team_a']?['id'];
    final teamBId = _match?['team_b']?['id'];
    final targetId = inningsIndex == 0 ? teamAId : teamBId;

    final playerStats = List<Map<String, dynamic>>.from(_match?['playerStats'] ?? []);
    final inningsBatters = playerStats.where((p) => p['team_id'] == targetId && (p['balls'] ?? 0) > 0).toList();
    final inningsBowlers = playerStats.where((p) => p['team_id'] != targetId && (p['overs'] ?? 0) > 0).toList();

    return Column(
      children: [
        _buildMiniHeader(['Batter', 'R', 'B', '4s', '6s', 'SR']),
        ...inningsBatters.map((p) => _battingRow(
          p['player_name'] ?? 'Unknown',
          p['is_out'] == true ? (p['dismissal_text'] ?? 'out') : 'not out',
          (p['runs'] ?? 0).toString(),
          (p['balls'] ?? 0).toString(),
          (p['fours'] ?? 0).toString(),
          (p['sixes'] ?? 0).toString(),
          _getStrikeRate(p)
        )),
        const Divider(height: 1),
        _buildMiniHeader(['Bowler', 'O', 'M', 'R', 'W', 'ER']),
        ...inningsBowlers.map((p) => _bowlingRow(
          p['player_name'] ?? 'Unknown',
          (p['overs'] ?? 0).toString(),
          '0',
          (p['runs_conceded'] ?? 0).toString(),
          (p['wickets'] ?? 0).toString(),
          _getEconomy(p)
        )),
      ],
    );
  }

  Widget _didNotBatSection(String players) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Did not bat', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          const SizedBox(height: 8),
          Text(players, style: const TextStyle(color: Colors.grey, fontSize: 12, height: 1.4)),
        ],
      ),
    );
  }

  Widget _battingRow(String name, String desc, String r, String b, String f, String s, String sr) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(color: AppColors.primaryElectric, fontWeight: FontWeight.bold)),
                Text(desc, style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ],
            ),
          ),
          Expanded(child: Text(r, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: Text(b, textAlign: TextAlign.center)),
          Expanded(child: Text(f, textAlign: TextAlign.center)),
          Expanded(child: Text(s, textAlign: TextAlign.center)),
          Expanded(child: Text(sr, textAlign: TextAlign.center)),
        ],
      ),
    );
  }

  Widget _bowlingRow(String name, String o, String m, String r, String w, String er) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(flex: 3, child: Text(name, style: const TextStyle(color: AppColors.primaryElectric, fontWeight: FontWeight.bold))),
          Expanded(child: Text(o, textAlign: TextAlign.center)),
          Expanded(child: Text(m, textAlign: TextAlign.center)),
          Expanded(child: Text(r, textAlign: TextAlign.center)),
          Expanded(child: Text(w, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: Text(er, textAlign: TextAlign.center)),
        ],
      ),
    );
  }

  Widget _buildExtraTotal(String extras, String total) {
    return Column(
      children: [
        _infoRow('Extras', extras),
        _infoRow('Total', total, isBold: true),
      ],
    );
  }

  Widget _infoRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          SizedBox(width: 60, child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal))),
        ],
      ),
    );
  }

  // --- SQUADS TAB ---
  Widget _buildSquadsTab() {
    final teamA = _match?['team_a']?['name'] ?? 'Team A';
    final teamB = _match?['team_b']?['name'] ?? 'Team B';
    final teamAId = _match?['team_a']?['id'];
    final teamBId = _match?['team_b']?['id'];
    
    final playerStats = List<Map<String, dynamic>>.from(_match?['playerStats'] ?? []);
    final squadA = playerStats.where((p) => p['team_id'] == teamAId).toList();
    final squadB = playerStats.where((p) => p['team_id'] == teamBId).toList();

    final maxLen = squadA.length > squadB.length ? squadA.length : squadB.length;

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: Colors.grey.withOpacity(0.05),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [const Icon(Icons.shield, size: 20, color: AppColors.primaryElectric), const SizedBox(width: 8), Text(teamA, style: const TextStyle(fontWeight: FontWeight.bold))]),
              Row(children: [Text(teamB, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(width: 8), const Icon(Icons.shield, size: 20, color: AppColors.accentSunset)]),
            ],
          ),
        ),
        _buildSquadTitle('Squad Players'),
        Expanded(
          child: ListView.builder(
            itemCount: maxLen,
            itemBuilder: (context, index) {
              final pA = index < squadA.length ? squadA[index] : null;
              final pB = index < squadB.length ? squadB[index] : null;
              return _squadRow(
                pA?['player_name'] ?? (pA != null ? 'Player' : ''),
                pA != null ? 'Team A' : '',
                pB?['player_name'] ?? (pB != null ? 'Player' : ''),
                pB != null ? 'Team B' : '',
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSquadTitle(String title) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8),
      color: Colors.grey.withOpacity(0.02),
      child: Center(child: Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey))),
    );
  }

  Widget _squadTotalRow(String title) {
    return _buildSquadTitle(title);
  }

  Widget _squadRow(String p1, String r1, String p2, String r2) {
    return Row(
      children: [
        Expanded(child: _playerItem(p1, r1, false)),
        Container(width: 1, height: 40, color: Colors.grey.withOpacity(0.1)),
        Expanded(child: _playerItem(p2, r2, true)),
      ],
    );
  }

  Widget _playerItem(String name, String role, bool right) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        mainAxisAlignment: right ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!right) ...[const CircleAvatar(radius: 18, backgroundColor: Color(0xFFE5E7EB), child: Icon(Icons.person, size: 20, color: Colors.white)), const SizedBox(width: 12)],
          Expanded(
            child: Column(
              crossAxisAlignment: right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                Text(role, style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ],
            ),
          ),
          if (right) ...[const SizedBox(width: 12), const CircleAvatar(radius: 18, backgroundColor: Color(0xFFE5E7EB), child: Icon(Icons.person, size: 20, color: Colors.white))],
        ],
      ),
    );
  }

  // --- OVERS TAB ---
  Widget _buildOversTab() {
    final commentary = List<Map<String, dynamic>>.from(_match?['commentary'] ?? []);
    if (commentary.isEmpty) {
      return const Center(child: Text('No overs data yet.'));
    }

    // Group by over number
    final Map<int, List<Map<String, dynamic>>> oversGroups = {};
    for (var ball in commentary) {
      final overNum = ball['over_number'] as int;
      oversGroups.putIfAbsent(overNum, () => []).add(ball);
    }

    final sortedOverNums = oversGroups.keys.toList()..sort((a, b) => b.compareTo(a));

    return ListView.builder(
      itemCount: sortedOverNums.length,
      itemBuilder: (context, index) {
        final overNum = sortedOverNums[index];
        final balls = oversGroups[overNum]!;
        final ballEvents = balls.map((b) => b['event_type']?.toString() ?? '0').toList();
        final runs = balls.fold<int>(0, (sum, b) => sum + ((b['runs'] as int?) ?? 0));
        
        return _overDetailCard(
          'Ov $overNum',
          'Details for over $overNum',
          '$runs runs',
          ballEvents,
        );
      },
    );
  }

  Widget _overDetailCard(String over, String desc, String runs, List<String> balls) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(over, style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                  Text(runs, style: const TextStyle(color: Colors.grey)),
                ],
              ),
              const SizedBox(height: 4),
              Text(desc, style: const TextStyle(color: Colors.black87, fontSize: 13)),
              const SizedBox(height: 12),
              Row(
                children: balls.map((b) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: _eventBadge(b),
                )).toList(),
              ),
            ],
          ),
        ),
        const Divider(height: 1),
      ],
    );
  }

  // --- HIGHLIGHTS TAB ---
  Widget _buildHighlightsTab() {
    final commentary = List<Map<String, dynamic>>.from(_match?['commentary'] ?? []);
    final highlights = commentary.where((c) {
      final event = c['event_type']?.toString();
      return event == 'W' || event == '4' || event == '6';
    }).toList();

    if (highlights.isEmpty) {
      return const Center(child: Text('No major highlights yet.'));
    }

    return ListView.builder(
      itemCount: highlights.length,
      itemBuilder: (context, index) {
        final c = highlights[index];
        return _commentaryItem(
          '${c['over_number']}.${c['ball_number']}',
          c['event_type'] ?? '',
          c['commentary_text'] ?? '',
        );
      },
    );
  }

  // --- ANALYSIS TAB ---
  Widget _buildAnalysisTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 24),
          _buildAnalysisHeader('3D WAGON WHEEL'),
          const SizedBox(height: 16),
          _buildWagonWheel(),
          const SizedBox(height: 40),
          _buildAnalysisHeader('3D RUN RATE TRANSITION'),
          const SizedBox(height: 16),
          _buildRunRateChart(),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Widget _buildAnalysisHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 20,
            decoration: BoxDecoration(
              color: AppColors.primaryElectric,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWagonWheel() {
    return Container(
      height: 320,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: CustomPaint(
        painter: _WagonWheelPainter(),
      ),
    );
  }

  Widget _buildRunRateChart() {
    return Container(
      height: 240,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.primaryElectric.withOpacity(0.05),
            Colors.white,
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppColors.primaryElectric.withOpacity(0.1)),
      ),
      child: CustomPaint(
        painter: _RunRatePainter(),
      ),
    );
  }
}

class _LiveBadge extends StatelessWidget {
  const _LiveBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(4)),
      child: const Text('LIVE', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)),
    );
  }
}

class _PillChip extends StatelessWidget {
  final String label;
  const _PillChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.backgroundCardAlt,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.backgroundCard),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
      ),
    );
  }
}

class _BallAndBatPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();

    // 1. Indigo Splatters (Inspired by the "ink splash" reference)
    final splatterPaint = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);
    
    // Main top splatter (dominant)
    final topSplatterGradient = LinearGradient(
      colors: [
        AppColors.primaryElectric.withOpacity(0.18),
        AppColors.primaryElectric.withOpacity(0.1),
        Colors.transparent,
      ],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    );
    splatterPaint.shader = topSplatterGradient.createShader(Rect.fromLTWH(0, -50, size.width, 350));
    
    final mainSplatterPath = Path();
    mainSplatterPath.moveTo(-50, -50);
    mainSplatterPath.lineTo(size.width + 50, -50);
    mainSplatterPath.lineTo(size.width + 50, 200);
    mainSplatterPath.quadraticBezierTo(size.width * 0.7, 300, size.width * 0.4, 220);
    mainSplatterPath.quadraticBezierTo(size.width * 0.2, 350, -50, 250);
    mainSplatterPath.close();
    canvas.drawPath(mainSplatterPath, splatterPaint);

    // Irregular ink drops for "distressed" look
    final dropPaint = Paint()..color = AppColors.primaryElectric.withOpacity(0.08);
    canvas.drawCircle(Offset(size.width * 0.2, 320), 40, dropPaint);
    canvas.drawCircle(Offset(size.width * 0.75, 280), 60, dropPaint);
    canvas.drawCircle(Offset(size.width * 0.1, 450), 25, dropPaint..color = AppColors.primaryElectric.withOpacity(0.05));
    canvas.drawCircle(Offset(size.width * 0.85, 520), 35, dropPaint);

    // 2. Stylized Cricket Bat (On the left silhouette - KEPT AS IS)
    final batPaint = Paint()
      ..color = AppColors.primaryElectric.withOpacity(0.05)
      ..style = PaintingStyle.fill;
    
    final batPath = Path();
    // Handle
    batPath.moveTo(25, 50);
    batPath.lineTo(35, 50);
    batPath.lineTo(35, 150);
    batPath.lineTo(25, 150);
    batPath.close();
    // Shoulder & Blade
    batPath.moveTo(15, 150);
    batPath.lineTo(45, 150);
    batPath.lineTo(48, 550);
    batPath.quadraticBezierTo(30, 580, 12, 550);
    batPath.close();
    
    canvas.save();
    canvas.translate(10, 50);
    canvas.rotate(-0.05);
    canvas.drawPath(batPath, batPaint);
    canvas.restore();

    // 3. Stylized Cricket Ball (Near the bat - KEPT AS IS)
    final ballGradient = RadialGradient(
      colors: [
        AppColors.accentSunset.withOpacity(0.15),
        AppColors.accentSunset.withOpacity(0.05),
      ],
    );
    paint.shader = ballGradient.createShader(Rect.fromCircle(center: const Offset(40, 650), radius: 40));
    canvas.drawCircle(const Offset(40, 650), 40, paint);
    
    // Ball seam detail
    final seamPaint = Paint()
      ..color = AppColors.accentSunset.withOpacity(0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawArc(Rect.fromCircle(center: const Offset(40, 650), radius: 40), -1.0, 2.0, false, seamPaint);

    // 4. Bubbles (Floating around - KEPT AS IS)
    final bubblePaint = Paint()..style = PaintingStyle.fill;
    final randOffsets = [
      const Offset(0.2, 0.1), const Offset(0.8, 0.2), 
      const Offset(0.1, 0.4), const Offset(0.9, 0.5),
      const Offset(0.3, 0.7), const Offset(0.7, 0.8),
      const Offset(0.5, 0.9), const Offset(0.85, 0.15),
    ];
    final randSizes = [20.0, 40.0, 15.0, 30.0, 25.0, 45.0, 20.0, 35.0];
    final bubbleColors = [
      AppColors.primaryElectric,
      AppColors.accentSunset,
      const Color(0xFF10B981), // Teal/Green for variety
      const Color(0xFF7C3AED), // Purple
      AppColors.primaryElectric,
      AppColors.accentSunset,
      AppColors.primaryElectric,
      const Color(0xFF0EA5E9), // Cyan
    ];

    for (int i = 0; i < randOffsets.length; i++) {
      final center = Offset(size.width * randOffsets[i].dx, size.height * randOffsets[i].dy);
      final radius = randSizes[i];
      final color = bubbleColors[i % bubbleColors.length];
      
      bubblePaint.shader = RadialGradient(
        colors: [
          color.withOpacity(0.25), // Vibrant center
          color.withOpacity(0.08),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
      
      canvas.drawCircle(center, radius, bubblePaint);
      
      // Bubble highlight for 3D effect
      final highlightPaint = Paint()
        ..color = Colors.white.withOpacity(0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
      canvas.drawCircle(center + Offset(-radius * 0.3, -radius * 0.3), radius * 0.2, highlightPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _WagonWheelPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 20;

    // Grass Background (3D styled)
    final fieldPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF10B981).withOpacity(0.1),
          const Color(0xFF059669).withOpacity(0.2),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    
    canvas.drawCircle(center, radius, fieldPaint);
    
    // Boundary line
    final boundaryPaint = Paint()
      ..color = Colors.white.withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(center, radius, boundaryPaint);

    // Pitch (3D styled)
    final pitchPaint = Paint()..color = const Color(0xFFFDE68A).withOpacity(0.8);
    final pitchRect = Rect.fromCenter(center: center, width: 24, height: 60);
    canvas.drawRRect(RRect.fromRectAndRadius(pitchRect, const Radius.circular(4)), pitchPaint);

    // Shots (3D styled strokes)
    final shotPaint = Paint()
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    final List<Map<String, dynamic>> shots = [
      {'angle': 0.5, 'dist': 0.8, 'type': '4', 'color': Colors.blue},
      {'angle': 1.2, 'dist': 0.95, 'type': '6', 'color': Colors.purple},
      {'angle': -0.8, 'dist': 0.6, 'type': '1', 'color': Colors.grey},
      {'angle': 3.5, 'dist': 0.85, 'type': '4', 'color': Colors.blue},
      {'angle': -2.5, 'dist': 0.7, 'type': '2', 'color': Colors.orange},
    ];

    for (var shot in shots) {
      final angle = shot['angle'] as double;
      final dist = shot['dist'] as double;
      final color = shot['color'] as Color;
      
      final endPoint = Offset(
        center.dx + radius * dist * (angle).clamp(-1, 1), 
        center.dy + radius * dist * (1 - angle.abs()).clamp(-1, 1),
      );

      // Shadow for 3D depth
      shotPaint.color = Colors.black.withOpacity(0.1);
      canvas.drawLine(center + const Offset(2, 2), endPoint + const Offset(2, 2), shotPaint);

      // Actual shot line
      shotPaint.color = color.withOpacity(0.8);
      canvas.drawLine(center, endPoint, shotPaint);

      // Hit point
      canvas.drawCircle(endPoint, 4, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _RunRatePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    final path = Path();
    final List<double> values = [4, 6, 5, 8, 7, 9, 6, 11, 8, 10];
    
    final stepX = size.width / (values.length - 1);
    final maxY = 15.0;

    path.moveTo(0, size.height - (values[0] / maxY) * size.height);

    for (int i = 1; i < values.length; i++) {
        final x = i * stepX;
        final y = size.height - (values[i] / maxY) * size.height;
        path.lineTo(x, y);
    }

    // 3D Depth Shadow Path
    final shadowPath = path.shift(const Offset(0, 10));
    
    final shadowPaint = Paint()
      ..color = AppColors.primaryElectric.withOpacity(0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6;
    
    canvas.drawPath(shadowPath, shadowPaint);

    // Main Run Rate Line
    paint.shader = LinearGradient(
      colors: [AppColors.primaryElectric, AppColors.accentSunset],
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
    ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    
    canvas.drawPath(path, paint);

    // Area under the curve (3D-ish gradient)
    final fillPath = Path.from(path);
    fillPath.lineTo(size.width, size.height);
    fillPath.lineTo(0, size.height);
    fillPath.close();

    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          AppColors.primaryElectric.withOpacity(0.15),
          Colors.white.withOpacity(0),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, fillPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
