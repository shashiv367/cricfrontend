import 'package:flutter/material.dart';

/// Color palette inspired by the "Ballista" (formerly SportBet) purple/white UI design.
class AppColors {
  // Main Backgrounds
  static const Color backgroundLight = Color(0xFFF3F4F6); // Light Grey for scaffold
  static const Color backgroundWhite = Color(0xFFFFFFFF); // White for cards/containers

  // Primary Branding (Electric Indigo & Sunset palette)
  static const Color primaryElectric = Color(0xFF4F46E5); // Deep Indigo
  static const Color primaryElectricLight = Color(0xFF6366F1);
  static const Color accentSunset = Color(0xFFF43F5E); // Vibrant Rose/Sunset
  static const Color accentGlow = Color(0xFFFB923C); // Warm Orange Glow

  // Aliases for branding
  static const Color primaryTeal = Color(0xFF00A381); // Keep for legacy
  static const Color primaryPurple = Color(0xFF6D28D9); // Keep for legacy
  static const Color primaryPurpleLight = Color(0xFF8B5CF6);
  static const Color primaryPurpleDark = Color(0xFF5B21B6);

  // Accents
  static const Color accentRed = Color(0xFFF43F5E); // Pinkish Red
  static const Color accentGreen = Color(0xFF10B981); // Green
  static const Color accentYellow = Color(0xFFF59E0B); // Warning

  // Text Colors
  static const Color textPrimary = Color(0xFF1F2937); // Dark Grey
  static const Color textSecondary = Color(0xFF6B7280); // Medium Grey
  static const Color textWhite = Color(0xFFFFFFFF); // White text

  // Dividers & Borders
  static const Color divider = Color(0xFFE5E7EB);
  static const Color border = Color(0xFFE5E7EB);

  // Shadows
  static Color shadowColor = const Color(0xFF9CA3AF).withOpacity(0.2);

  // Backward compatibility (mapping old names to new palette where sensible)
  static const Color backgroundDark = backgroundLight; // Mapping to light for full switch
  static const Color backgroundCard = backgroundWhite;
  static const Color backgroundCardAlt = Color(0xFFF9FAFB);
  static const Color backgroundWhiteAlt = backgroundCardAlt;
  static const Color primaryBlue = primaryPurple; // Map old primary to new primary
  static const Color liveRed = accentRed;
  static const Color successGreen = accentGreen;
  
  // Re-added missing aliases
  static const Color textDark = textPrimary;    
  static const Color textLight = textSecondary; 
  static const Color textMuted = textSecondary;

  // Light Violet/Lavender Palette (for Player Dashboard) - Correct Design
  static const Color lavenderBg = Color(0xFFE8E3F3);        // Main background
  static const Color cardLavender = Color(0xFFEDE8F8);      // Light lavender cards (batting)
  static const Color cardPink = Color(0xFFFCE8E8);          // Light pink cards (bowling)  
  static const Color cardPeach = Color(0xFFFFF4E6);         // Peach cards (recent form)
  static const Color cardWhitePurple = Color(0xFFF5F2FF);   // White-purple stats cards
  static const Color accentPurple = Color(0xFF7E6FCC);      // Primary purple accent (buttons, icons)
  static const Color profileRing = Color(0xFFB8A9E8);       // Profile photo ring
  static const Color softGreen = Color(0xFF6BCF7F);         // Success/positive indicators
}
