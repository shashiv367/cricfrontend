import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/home_screen.dart';
import 'screens/live_match_screen.dart';
import 'screens/team_screen.dart';
import 'screens/ranking_screen.dart';
import 'screens/live_detail_screen.dart';
import 'screens/auth_screen.dart';
import 'utils/app_colors.dart';
import 'widgets/bottom_nav_bar.dart';
import 'config/app_config.dart';
import 'screens/user_dashboard_screen.dart';
import 'screens/series_detail_screen.dart';
import 'screens/team_squad_detail_screen.dart';
import 'screens/more_screen.dart';
import 'widgets/splatter_background.dart';
import 'screens/player_dashboard_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Use config with defaults - no need to pass --dart-define every time!
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
  );
  runApp(const CricbuzzApp());
}

class CricbuzzApp extends StatelessWidget {
  const CricbuzzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Innings',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.backgroundLight,
        fontFamily: 'Roboto',
        colorScheme: const ColorScheme.light(
          primary: AppColors.primaryPurple,
          secondary: AppColors.primaryPurpleLight,
          background: AppColors.backgroundLight,
          surface: AppColors.backgroundWhite,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.primaryPurple,
          foregroundColor: AppColors.textWhite,
          elevation: 0,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
      routes: {
        '/live-detail': (context) => const LiveDetailScreen(),
        '/auth': (context) => const AuthScreen(),
        '/home': (context) => const MainScreen(),
        '/dashboard': (context) => const UserDashboardScreen(),
        '/series-detail': (context) => const SeriesDetailScreen(),
        '/team-squad': (context) => const TeamSquadDetailScreen(),
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _shockwaveController;
  late AnimationController _lightingController;
  
  late Animation<double> _opacityAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;
  late Animation<double> _shockwaveAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 2500),
      vsync: this,
    );

    _shockwaveController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _lightingController = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    )..repeat();

    _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.4, curve: Curves.easeIn)),
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.6, curve: Curves.elasticOut)),
    );

    _rotationAnimation = Tween<double>(begin: 0.0, end: 10.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.8, curve: Curves.easeOutCubic)),
    );

    _shockwaveAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _shockwaveController, curve: Curves.easeOutExpo),
    );

    _controller.forward().then((_) {
      _shockwaveController.forward();
      Future.delayed(const Duration(seconds: 1), () {
        if (mounted) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const MainScreen()),
          );
        }
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _shockwaveController.dispose();
    _lightingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E1B4B), // Indigo 950
      body: Stack(
        children: [
          // 1. Dynamic Stadium Lighting Background
          AnimatedBuilder(
            animation: _lightingController,
            builder: (context, child) {
              return CustomPaint(
                painter: _StadiumLightingPainter(_lightingController.value),
                size: Size.infinite,
              );
            },
          ),
          
          Center(
            child: AnimatedBuilder(
              animation: Listenable.merge([_controller, _shockwaveController]),
              builder: (context, child) {
                return Stack(
                  alignment: Alignment.center,
                  children: [
                    // 2. Shockwave Effect (Under the ball)
                    if (_shockwaveController.isAnimating || _shockwaveController.isCompleted)
                      CustomPaint(
                        painter: _ShockwavePainter(_shockwaveAnimation.value),
                        size: const Size(300, 300),
                      ),
                    
                    // 3. Speed Trails (Follows the ball entry)
                    if (_controller.value < 0.6)
                      CustomPaint(
                        painter: _SpeedTrailPainter(_controller.value),
                        size: const Size(200, 200),
                      ),

                    // 4. 3D Animated Cricket Ball
                    FadeTransition(
                      opacity: _opacityAnimation,
                      child: ScaleTransition(
                        scale: _scaleAnimation,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Transform.rotate(
                              angle: _rotationAnimation.value,
                              child: const _Innings3DBall(),
                            ),
                            const SizedBox(height: 40),
                            // Brand Tagline
                            const Text(
                              'PRECISION • PACE • PERFORMANCE',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 4.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Innings3DBall extends StatelessWidget {
  const _Innings3DBall();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF06B6D4).withOpacity(0.3), // Cyan glow
            blurRadius: 40,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 30,
            offset: const Offset(10, 20),
          ),
        ],
        gradient: const RadialGradient(
          center: Alignment(-0.3, -0.4),
          radius: 0.8,
          colors: [
            Color(0xFFFB7185), // Rose 400 (High-key)
            Color(0xFFE11D48), // Rose 600 (Mid-tone)
            Color(0xFF4C0519), // Rose 950 (Deep Shadow)
          ],
        ),
      ),
      child: Stack(
        children: [
          // Cyan Accent Glow (Top Edge)
          Positioned(
            top: 10,
            left: 40,
            right: 40,
            child: Container(
              height: 20,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF22D3EE).withOpacity(0.4),
                    blurRadius: 15,
                  ),
                ],
              ),
            ),
          ),
          // The Seam (White lines)
          Center(
            child: Container(
              height: 4,
              width: 150,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.4),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 2,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 1,
                  width: 150,
                  color: Colors.white.withOpacity(0.2),
                ),
                const SizedBox(height: 6),
                Container(
                  height: 1,
                  width: 150,
                  color: Colors.white.withOpacity(0.2),
                ),
              ],
            ),
          ),
          // Specular Highlight for 3D effect
          Positioned(
            top: 25,
            left: 30,
            child: Container(
              width: 40,
              height: 25,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.25),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.1),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const PlayerDashboardScreen(), // Temporarily set as home to show changes
    const LiveMatchScreen(),     // Matches
    const Center(child: Text('Videos Tab')),   // Videos
    const Center(child: Text('News Tab')),     // News
    const MoreScreen(),     // More
  ];

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    double topOffset = 0.0;
    if (_currentIndex == 1) { // Matches
      topOffset = 130.0;
    } else if (_currentIndex == 4) { // More
      topOffset = 140.0;
    } else if (_currentIndex == 2 || _currentIndex == 3) { // Videos/News placeholders
      topOffset = 100.0;
    }

    return SplatterBackground(
      topOffset: topOffset,
      child: Scaffold(
        backgroundColor: Colors.transparent, // Allow splatter to show through
        appBar: _currentIndex == 0 ? _buildDashboardAppBar() : null,
        body: _screens[_currentIndex],
        bottomNavigationBar: BottomNavBar(
          currentIndex: _currentIndex,
          onTap: _onTabTapped,
        ),
      ),
    );
  }

  PreferredSizeWidget _buildDashboardAppBar() {
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.primaryElectric, Color(0xFF7C3AED)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
      elevation: 0,
      title: const Text(
        'Innings',
        style: TextStyle(
          color: Colors.white,
          fontSize: 26,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.5,
        ),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/auth');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white24,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 20),
            ),
            child: const Text(
              'Login',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ],
    );
  }
}

class _StadiumLightingPainter extends CustomPainter {
  final double animation;
  _StadiumLightingPainter(this.animation);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF4F46E5).withOpacity(0.1)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 50);

    // Beams of light moving across the screen
    for (var i = 0; i < 4; i++) {
      final x = (size.width * (i / 3) + (size.width * animation * 0.5)) % size.width;
      final path = Path()
        ..moveTo(x - 50, -100)
        ..lineTo(x + 50, -100)
        ..lineTo(x + 150, size.height + 100)
        ..lineTo(x - 150, size.height + 100)
        ..close();
      canvas.drawPath(path, paint..color = const Color(0xFF4F46E5).withOpacity(0.08));
    }

    // Static corner glow (Stadium floodlight vibe)
    final cornerPaint = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFF06B6D4).withOpacity(0.2), Colors.transparent],
      ).createShader(Rect.fromCircle(center: const Offset(0, 0), radius: 300));
    canvas.drawCircle(const Offset(0, 0), 300, cornerPaint);
    
    final cornerPaint2 = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFF7C3AED).withOpacity(0.15), Colors.transparent],
      ).createShader(Rect.fromCircle(center: Offset(size.width, size.height), radius: 400));
    canvas.drawCircle(Offset(size.width, size.height), 400, cornerPaint2);
  }

  @override
  bool shouldRepaint(covariant _StadiumLightingPainter oldDelegate) => true;
}

class _SpeedTrailPainter extends CustomPainter {
  final double animation;
  _SpeedTrailPainter(this.animation);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    final random = (double seed) => (seed * 12345.67) % 1.0;

    for (var i = 0; i < 15; i++) {
      final seed = i * 1.0;
      final startOffset = Offset(
        size.width / 2 + (random(seed) - 0.5) * 100,
        size.height / 2 + (random(seed + 1) - 0.5) * 100,
      );
      
      final length = 100 * (1 - animation);
      final angle = random(seed + 2) * 2 * 3.14159;
      
      final endOffset = Offset(
        startOffset.dx + length * 2 * (animation - 0.5),
        startOffset.dy + length * 2 * (0.5 - animation),
      );

      paint.color = const Color(0xFF06B6D4).withOpacity((1 - animation) * 0.4);
      canvas.drawLine(startOffset, endOffset, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SpeedTrailPainter oldDelegate) => true;
}

class _ShockwavePainter extends CustomPainter {
  final double animation;
  _ShockwavePainter(this.animation);

  @override
  void paint(Canvas canvas, Size size) {
    if (animation == 0) return;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = 100 + animation * 150;
    
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4 * (1 - animation)
      ..color = const Color(0xFF06B6D4).withOpacity((1 - animation) * 0.5);

    canvas.drawCircle(center, radius, paint);
    
    // Outer ripple
    paint.strokeWidth = 2 * (1 - animation);
    canvas.drawCircle(center, radius + 20, paint..color = const Color(0xFF7C3AED).withOpacity((1 - animation) * 0.3));
  }

  @override
  bool shouldRepaint(covariant _ShockwavePainter oldDelegate) => true;
}
