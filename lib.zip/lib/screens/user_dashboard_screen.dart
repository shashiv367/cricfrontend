import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../services/api_service.dart';
import '../services/supabase_client.dart';
import 'dart:developer' as developer;

class UserDashboardScreen extends StatefulWidget {
  const UserDashboardScreen({super.key});

  @override
  State<UserDashboardScreen> createState() => _UserDashboardScreenState();
}

class _UserDashboardScreenState extends State<UserDashboardScreen> {
  late final PageController _pageController;
  List<Map<String, dynamic>> _matches = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.9);
    _loadMatches();
  }

  Future<void> _loadMatches() async {
    setState(() => _loading = true);
    try {
      final token = await supabase.auth.currentSession?.accessToken;
      
      final response = await ApiService.listMatches(token: token);
      if (mounted) {
        setState(() {
          _matches = List<Map<String, dynamic>>.from(response['matches'] ?? []);
          _loading = false;
        });
      }
    } catch (e) {
      developer.log('Error loading matches: $e');
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircularProgressIndicator(color: AppColors.primaryElectric),
              const SizedBox(height: 16),
              Text('Connecting to server...', style: TextStyle(color: Colors.grey[600])),
            ],
          ),
        ),
      );
    }
 
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: RefreshIndicator(
        onRefresh: _loadMatches,
        color: AppColors.primaryElectric,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              if (_matches.isEmpty)
                _buildEmptyState()
              else
                _buildSlidingMatchCards(),
              const SizedBox(height: 24),
              _buildSectionHeader('FEATURED VIDEOS'),
              _buildFeaturedVideos(),
              const SizedBox(height: 24),
              _buildSectionHeader('PERSONALIZED FOR YOU'),
              _buildPersonalizedFeed(),
              const SizedBox(height: 24),
              _buildSectionHeader('TOP STORIES'),
              _buildTopStories(),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }
 
  Widget _buildEmptyState() {
    return Container(
      height: 200,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: AppColors.primaryElectric.withOpacity(0.05), blurRadius: 15, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cloud_off_outlined, size: 48, color: Colors.grey[300]),
          const SizedBox(height: 12),
          Text(
            'No matches found or server unreachable',
            style: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadMatches,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryElectric,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
            child: const Text('RETRY'),
          ),
        ],
      ),
    );
  }


  Widget _buildSlidingMatchCards() {
    return SizedBox(
      height: 240,
      child: PageView.builder(
        controller: _pageController,
        clipBehavior: Clip.none,
        itemCount: _matches.length,
        itemBuilder: (context, index) {
          return _buildMatchCard(_matches[index]);
        },
      ),
    );
  }

  Widget _buildMatchCard(Map<String, dynamic> match) {
    final teamA = match['team_a_details']?['name'] ?? 'Team A';
    final teamB = match['team_b_details']?['name'] ?? 'Team B';
    final score = match['score'];
    
    String teamAScore = '-';
    String teamBScore = '-';
    
    if (score != null) {
      teamAScore = '${score['team_a_score'] ?? 0}/${score['team_a_wkts'] ?? 0} (${score['team_a_overs'] ?? 0})';
      teamBScore = '${score['team_b_score'] ?? 0}/${score['team_b_wkts'] ?? 0} (${score['team_b_overs'] ?? 0})';
    }

    final status = match['status'] ?? 'scheduled';
    String statusText = status.toUpperCase();
    if (status == 'live') {
      statusText = 'LIVE MATCH';
    } else if (status == 'scheduled') {
      statusText = 'UPCOMING';
    } else if (status == 'completed') {
      statusText = 'RESULT';
    }

    final venue = match['venue_details']?['name'] ?? 'TBA';

    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(
          context, 
          '/live-detail',
          arguments: {'matchId': match['id']}
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppColors.primaryElectric.withOpacity(0.12),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '$statusText • $venue',
                        style: TextStyle(color: Colors.grey[600], fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      if (status == 'live')
                        const Icon(Icons.circle, size: 8, color: Colors.red)
                      else
                        Icon(Icons.notifications_none, size: 18, color: AppColors.primaryElectric.withOpacity(0.6)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _buildTeamIcon(teamA[0], Colors.blue),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          teamA, 
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.textPrimary),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(teamAScore, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppColors.textPrimary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _buildTeamIcon(teamB[0], Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          teamB, 
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.textPrimary),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(teamBScore, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppColors.textPrimary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    status == 'live' ? 'Match currently in progress' : 
                    status == 'scheduled' ? 'Match starts soon' : 'Match Completed',
                    style: TextStyle(
                      color: status == 'live' ? AppColors.accentSunset : AppColors.textSecondary, 
                      fontWeight: FontWeight.bold, 
                      fontSize: 12
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[50], 
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                         Navigator.pushNamed(
                          context, 
                          '/live-detail',
                          arguments: {'matchId': match['id'], 'initialTabIndex': 1} // 1 for Scorecard or Live
                        );
                      },
                      child: const Text('DETAILS', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.bold, fontSize: 12)),
                    ),
                  ),
                  Container(height: 16, width: 1, color: Colors.grey[300]),
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        Navigator.pushNamed(
                          context, 
                          '/live-detail',
                          arguments: {'matchId': match['id'], 'initialTabIndex': 3} // 3 for Squads
                        );
                      },
                      child: const Text('SQUADS', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.bold, fontSize: 12)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTeamIcon(String initial, Color color) {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        shape: BoxShape.circle,
        border: Border.all(color: color.withOpacity(0.5), width: 1),
      ),
      child: Center(
        child: Text(
          initial,
          style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
              letterSpacing: 1.0,
            ),
          ),
          const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.primaryElectric),
        ],
      ),
    );
  }

  Widget _buildFeaturedVideos() {
    return SizedBox(
      height: 240,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: 3,
        itemBuilder: (context, index) {
          return Container(
            width: 300,
            margin: const EdgeInsets.only(right: 16, bottom: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                      child: Container(
                        height: 160,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.grey[300]!, Colors.grey[100]!],
                          ),
                        ),
                        child: const Icon(Icons.play_circle_fill, size: 50, color: Colors.white),
                      ),
                    ),
                    Positioned(
                      bottom: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text('04:58', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    'India vs New Zealand, 3rd ODI: Match Preview & Analysis',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, height: 1.3, color: AppColors.textPrimary),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildPersonalizedFeed() {
    return SizedBox(
      height: 180,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: 3,
        itemBuilder: (context, index) {
          final items = [
            {'team': 'INDIA', 'title': 'Kohli\'s Masterclass: Analyzing his recent century', 'color': Colors.blue},
            {'team': 'RCB', 'title': 'IPL Auction: RCB\'s strategy for the next season', 'color': Colors.red},
            {'team': 'AUSTRALIA', 'title': 'Cummins: "We are ready for the challenge"', 'color': Colors.yellow},
          ];
          final item = items[index];

          return Container(
            width: 280,
            margin: const EdgeInsets.only(right: 16, bottom: 8),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  (item['color'] as Color).withOpacity(0.05),
                  Colors.white,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: (item['color'] as Color).withOpacity(0.1)),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4)),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: (item['color'] as Color).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        item['team'] as String,
                        style: TextStyle(color: item['color'] as Color, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const Spacer(),
                    const Icon(Icons.star, size: 14, color: AppColors.accentGlow),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  item['title'] as String,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, height: 1.2, color: AppColors.textPrimary),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
                const Spacer(),
                const Row(
                  children: [
                    Text('2h ago', style: TextStyle(color: Colors.grey, fontSize: 11)),
                    Spacer(),
                    Text('Read More', style: TextStyle(color: AppColors.primaryElectric, fontSize: 11, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildTopStories() {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 2,
      itemBuilder: (context, index) {
        return Container(
          margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 15, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                child: Container(
                  height: 220,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.grey[200]!, Colors.grey[50]!],
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                    ),
                  ),
                  child: const Icon(Icons.article, size: 60, color: Colors.white),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.primaryElectric.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text(
                        'ICC MEN\'S T20 WORLD CUP, 2026',
                        style: TextStyle(color: AppColors.primaryElectric, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 0.5),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Bangladesh overcome heartbreaks to seal historic series win against world champions',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, height: 1.25, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
