import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Transparent Header (splatter shows through)
        Container(
          width: double.infinity,
          padding: const EdgeInsets.only(top: 60, left: 24, bottom: 20, right: 24),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primaryElectric, Color(0xFF312E81)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Text(
            'More',
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
            ),
          ),
        ),
        
        // Settings List
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const SizedBox(height: 12),
              _buildMoreItem(
                icon: Icons.account_circle_outlined,
                title: 'My Account',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.play_circle_outline,
                title: 'Buzz Shorts',
                suffixIcon: const Text('⚡', style: TextStyle(fontSize: 16)),
                onTap: () {},
              ),
              const SizedBox(height: 12), // Section divider
              _buildMoreItem(
                icon: Icons.emoji_events_outlined,
                title: 'Browse Series',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.groups_outlined,
                title: 'Browse Team',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.person_outline,
                title: 'Browse Player',
                onTap: () {},
              ),
              const SizedBox(height: 12), // Section divider
              _buildMoreItem(
                icon: Icons.calendar_today_outlined,
                title: 'Schedule',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.history_outlined,
                title: 'Archives',
                onTap: () {},
              ),
              const SizedBox(height: 12), // Section divider
              _buildMoreItem(
                icon: Icons.trending_up,
                title: 'ICC Rankings - Men',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.trending_up,
                title: 'ICC Rankings - Women',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.bubble_chart_outlined,
                title: 'Records',
                onTap: () {},
              ),
              const SizedBox(height: 12), // Section divider
              _buildMoreItem(
                icon: Icons.stadium_outlined,
                title: 'ICC World Test Championship',
                onTap: () {},
              ),
              _buildMoreItem(
                icon: Icons.image_outlined,
                title: 'Photos',
                onTap: () {},
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMoreItem({
    required IconData icon,
    required String title,
    Widget? suffixIcon,
    required VoidCallback onTap,
  }) {
    return Container(
      color: Colors.white.withOpacity(0.8), // Slightly transparent to let background peek through
      child: Column(
        children: [
          ListTile(
            onTap: onTap,
            leading: Icon(
              icon,
              color: AppColors.primaryElectric,
              size: 24,
            ),
            title: Text(
              title,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: AppColors.textPrimary,
              ),
            ),
            trailing: suffixIcon ?? const Icon(
              Icons.chevron_right,
              color: Colors.grey,
              size: 20,
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
          ),
          const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
        ],
      ),
    );
  }
}
